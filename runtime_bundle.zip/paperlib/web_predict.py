"""Shared web inference: exactly the same raw-to-feature function as offline preparation."""
from __future__ import annotations
import numpy as np
import pandas as pd
from crrt_clean.common import StudyError
from crrt_clean.data import study_config
from crrt_clean.features import clean_observations
from crrt_clean.features_fast import event_features
from crrt_clean.models import predict_raw

def example_payload():
    # Entirely illustrative, no patient copied from either database.
    cfg=study_config();t0=pd.Timestamp('2024-01-02 12:00:00')
    e={'event_id':'ILLUSTRATIVE_EXAMPLE','patient_id':'EXAMPLE','encounter_id':'EXAMPLE','t0':str(t0),'start_time':str(t0-pd.Timedelta(hours=24)),'end_time':str(t0+pd.Timedelta(days=1)),'age':60,'sex':'F','specimen_site':'blood','antibiotic_exposure_7d':1,'antibiotic_classes_7d':2,'carbapenem_exposure_7d':0,'invasive_ventilation_t0':1}
    e.update({k:0 for k in cfg['history_fields']});e['history_diabetes']=1
    values={'heart_rate':94.,'temperature':37.5,'respiratory_rate':20.,'map':73.,'spo2':96.,'wbc':11.,'platelets':135.,'lactate':2.3,'creatinine':2.1,'glucose':156.}
    rows=[]
    for j,(f,v) in enumerate(values.items()):
        for i,h in enumerate([20,12,4,1]):rows.append({'measured_at':str(t0-pd.Timedelta(hours=h)),'feature':f,'value':v*(1+.015*(i-1)),'unit':cfg['unit_contract'][f]})
    return {'static':e,'observations':rows}

def build_input(payload):
    cfg=study_config()
    if not isinstance(payload,dict) or not {'static','observations'}.issubset(payload):raise StudyError('JSON needs static and observations fields')
    e=dict(payload['static']);r=pd.DataFrame(payload['observations'])
    t0=pd.to_datetime(e.get('t0'),format='ISO8601',errors='coerce')
    if pd.isna(t0):raise StudyError('Use an ISO T0, for example 2024-01-02 12:00:00')
    start=pd.to_datetime(e.get('start_time'),format='ISO8601',errors='coerce')
    if pd.isna(start) or start>t0:raise StudyError('Valid ICU start_time <= T0 is required')
    end=pd.to_datetime(e.get('end_time'),format='ISO8601',errors='coerce')
    if pd.isna(end):e['end_time']=str(t0+pd.Timedelta(seconds=1))
    if float(e.get('age',0))<18:raise StudyError('Adult research population only')
    e['patient_id']='LOCAL';e['encounter_id']='LOCAL';e['event_id']='LOCAL'
    need={'measured_at','feature','value','unit'}
    if not need.issubset(r):raise StudyError('Each observation needs measured_at, feature, value, unit')
    clocks=pd.to_datetime(r.measured_at,format='ISO8601',errors='coerce')
    if clocks.isna().any() or (clocks>t0).any():raise StudyError('Observation times must be ISO and not after T0')
    if (clocks<max(start,t0-pd.Timedelta(hours=24))).any():raise StudyError('Uploaded observations must lie in the pre-T0 ICU window')
    r['patient_id']='LOCAL';r['encounter_id']='LOCAL';r['source_id']=['LOCAL_'+str(i) for i in range(len(r))];r['priority']=1
    if 'available_at' not in r:r['available_at']=r.measured_at
    clean,bad=clean_observations(r,cfg)
    if len(bad):raise StudyError(f'{len(bad)} invalid measurements. Check units, ranges and times; no silent web correction.')
    tab,v,m,a=event_features(clean,pd.Series(e),cfg)
    X=pd.DataFrame([tab]);arrays=(v[None],m[None],a[None])
    return X,arrays,{'observations':len(clean),'dynamic_channels_observed':len(set(clean.feature)),'raw_time_policy':cfg['observation_time_policy']}

def predict_payload(bundle,payload):
    X,a,audit=build_input(payload);score=float(predict_raw(bundle,X,a,threads=2)[0]);return score,audit
