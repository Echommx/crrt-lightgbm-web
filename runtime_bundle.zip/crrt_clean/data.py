"""Original ISO exports -> audited culture-day inputs. No database or simulation APIs."""
from __future__ import annotations
import re,time,traceback
from pathlib import Path
import numpy as np
import pandas as pd
from .common import StudyError,load_json,save_json,signature,read_csv,required
from .storage import ROOT,hash_file,file_map,code_hash,completed,begin_stage,finish_stage,require_finished,environment
from .labels import validate_export_labels
from . import prepare_core

COMMON=['events.csv','observations.csv','reports.csv','antibiogram.csv','event_static.csv','static_evidence_audit.csv','culture_day_members.csv','run_log.csv']
REQUIRED={'mimic':COMMON+['target_orders.csv','treatment_label_audit.csv','treatment_matches.csv'],
          'zj':COMMON+['label_source_rows.csv','label_rule_dictionary.csv','label_config.csv','day_result_audit.csv','result_label_hits.csv']}
EXPECTED={'mimic':{'events':11501,'patients':1931,'positive_events':1014},'zj':{'events':3389,'patients':1298,'positive_events':148}}
WARNINGS=[
'Full-MIMIC fitting: training/apparent performance is NOT internal validation.',
'MIMIC outcome: recorded antibacterial R. ZJ outcome: literal ASCII r/R OR conservative species/phenotype proxy, not the same reference standard.',
'Any R does NOT mean MDR. No detected R / missing AST does NOT demonstrate susceptibility.',
'ZJ D_ANY_RENAL_KEYWORD_AUDIT does not confirm actual CRRT for every patient.',
'charttime_only and admission/discharge diagnosis history are retrospective proxies; not a prospective bedside prediction guarantee.',
'Previously examined ZJ data remain exploratory; this new software directory does not make them untouched validation data.'
]

def study_config():return load_json(ROOT/'configs/study.json')
def raw_path(source):return ROOT/'data'/source
def ready_path(source):return ROOT/'data/prepared'/source

def raw_fingerprint(source):
    if source not in REQUIRED:raise StudyError('source must be mimic or zj')
    folder=raw_path(source);missing=[n for n in REQUIRED[source] if not (folder/n).is_file()]
    if missing:raise StudyError(f'{folder}: missing {missing}. Put the CSVs DIRECTLY in data/{source}; do not nest mimic_iso/zj_iso folders.')
    return file_map(folder,names=REQUIRED[source])

def reject_synthetic_columns(cols,name):
    bad=[c for c in cols if re.match(r'(?i)(r\d{2}_|synthetic|original_label_R13)',str(c))]
    if bad:raise StudyError(f'{name}: synthetic export markers {bad}. This clean project uses original ISO, not R40/S0027 or simulation labels.')

def check_source(source,retry=False):
    start=time.perf_counter();raw=raw_path(source);cfg=study_config();hashes=raw_fingerprint(source)
    fingerprint=signature({'raw':hashes,'cfg':cfg,'code':code_hash()})
    out=ROOT/'outputs/check'/source
    if completed(out,fingerprint):return load_json(out/'summary.json')
    begin_stage(out,retry)
    try:
        for fn in REQUIRED[source]:
            hdr=pd.read_csv(raw/fn,encoding='utf-8-sig',nrows=0).columns
            reject_synthetic_columns(hdr,fn)
        ev=read_csv(raw/'events.csv')
        required(ev,['event_id','source','patient_id','encounter_id','hospital_id','culture_date','t0','start_time','end_time','y_primary'],'events')
        if set(ev.source)!={source}:raise StudyError('Wrong source dataset')
        if ev.event_id.duplicated().any():raise StudyError('Duplicate event_id')
        if ev.duplicated(['patient_id','hospital_id','culture_date']).any():raise StudyError('Duplicate patient/hospital/culture-day key')
        times={k:pd.to_datetime(ev[k],format='ISO8601',errors='coerce') for k in ['t0','start_time','end_time']}
        if any(v.isna().any() for v in times.values()):raise StudyError('t0/start_time/end_time must be complete ISO timestamps. No automatic DMY guessing.')
        if not ((times['start_time']<=times['t0'])&(times['t0']<times['end_time'])).all():raise StudyError('Culture outside its anchor ICU interval')
        y=pd.to_numeric(ev.y_primary,errors='coerce')
        if not y.isin([0,1]).all():raise StudyError('Outcome must be binary and complete')
        lab_audit=validate_export_labels(raw,ev,cfg)
        lab_audit.to_csv(out/'independent_label_audit.csv',index=False,encoding='utf-8-sig')
        log=read_csv(raw/'run_log.csv');required(log,['step'],'run_log')
        if not log.step.eq('local_review').any():raise StudyError('Exported local_review stage is absent')
        obs_rows=0;invalid_clock=0;feature_counts={};units={}
        for chunk in pd.read_csv(raw/'observations.csv',dtype=str,keep_default_na=False,encoding='utf-8-sig',chunksize=200000):
            obs_rows+=len(chunk)
            required(chunk,['patient_id','encounter_id','feature','value','unit','measured_at','source_id'],'observations')
            invalid_clock+=int(pd.to_datetime(chunk.measured_at,format='ISO8601',errors='coerce').isna().sum())
            unknown=set(chunk.feature)-set(cfg['features'])
            if unknown:raise StudyError('Unexpected observation features '+str(sorted(unknown)))
            if chunk.source_id.str.contains('SYNTHETIC|R40_SYN|R29_SYN',case=False,regex=True).any():raise StudyError('Synthetic observation IDs found')
            for f,n in chunk.feature.value_counts().items():feature_counts[f]=feature_counts.get(f,0)+int(n)
            for f,u in zip(chunk.feature,chunk.unit):units.setdefault(f,set()).add(u)
        if invalid_clock:raise StudyError(f'{invalid_clock} unparseable measured_at values. Use the corrected ISO export, not raw DMY.')
        if set(cfg['features'])-set(feature_counts):raise StudyError('An entire observation channel is absent')
        counts={'source':source,'events':len(ev),'patients':int(ev.patient_id.nunique()),'positive_events':int(y.sum()),'positive_patients':int(ev.loc[y.eq(1),'patient_id'].nunique()),'observations':obs_rows,'positive_fraction':float(y.mean()),'export_local_review_present':True,'label_audit':'PASS','data_kind':'ORIGINAL_NON_SYNTHETIC'}
        counts['reference_count_differences']={k:{'observed':counts[k],'reference':v} for k,v in EXPECTED[source].items() if counts[k]!=v}
        counts['warnings']=WARNINGS
        if source=='zj':
            counts['unknown_site_events']=int(ev.specimen_site.eq('unknown').sum())
            counts['carbapenem_exposed_events']=int(pd.to_numeric(ev.carbapenem_exposure_7d,errors='coerce').eq(1).sum())
        pd.DataFrame([{'feature':f,'rows':feature_counts.get(f,0),'units':' | '.join(sorted(units.get(f,set()))),'expected_unit':cfg['unit_contract'][f]} for f in cfg['features']]).to_csv(out/'observation_channels.csv',index=False)
        save_json(out/'summary.json',counts);save_json(out/'input_hashes.json',hashes)
        save_json(out/'environment.json',environment())
        finish_stage(out,fingerprint,{'seconds':time.perf_counter()-start})
        print(f'CHECK {source}: {counts["events"]:,} events, {counts["patients"]:,} patients, {counts["positive_events"]:,} positives; independent label audit PASS',flush=True)
        return counts
    except Exception as e:
        save_json(out/'FAILURE.json',{'error':str(e),'traceback':traceback.format_exc()});raise

def prepare_source(source,retry=False):
    check_source(source,retry=retry)
    hashes=raw_fingerprint(source);cfg=study_config()
    fingerprint=signature({'raw':hashes,'cfg':cfg,'code':code_hash()})
    out=ready_path(source)
    if completed(out,fingerprint):return out
    begin_stage(out,retry)
    try:
        prepare_core.prepare(raw_path(source),ROOT/'configs/study.json',out)
        meta=load_json(out/'manifest.json');meta['data_kind']='ORIGINAL_NON_SYNTHETIC';meta['original_raw_hashes']=hashes
        meta['warnings']=WARNINGS
        save_json(out/'manifest.json',meta)
        finish_stage(out,fingerprint)
        return out
    except Exception as e:
        save_json(out/'FAILURE.json',{'error':str(e),'traceback':traceback.format_exc()});raise

def load_source(source):
    path=ready_path(source);require_finished(path)
    ev,X,arrays,meta=prepare_core.load_prepared(path)
    if meta.get('data_kind')!='ORIGINAL_NON_SYNTHETIC':raise StudyError('Only original ISO data accepted')
    return ev,X,arrays,meta
