from __future__ import annotations
import hashlib, json, re, unicodedata
from pathlib import Path
import numpy as np
import pandas as pd

class StudyError(RuntimeError):
    """Invalid protocol, input contract, or leakage-sensitive operation."""

def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_json(path, value):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    def convert(x):
        if isinstance(x, (np.integer,np.floating)): return x.item()
        if isinstance(x, (np.bool_,)): return bool(x)
        if isinstance(x, (pd.Timestamp,Path)): return str(x)
        if isinstance(x, np.ndarray): return x.tolist()
        raise TypeError(type(x).__name__)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=convert),encoding='utf-8')

def signature(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def read_csv(path):
    return pd.read_csv(path,dtype=str,keep_default_na=False,encoding='utf-8-sig')

def required(df, columns, title):
    missing=sorted(set(columns)-set(df.columns))
    if missing: raise StudyError(f'{title}: missing columns {missing}')

def bool_value(x):
    return str(x).strip().lower() in {'1','true','t','yes','y'}

def normalize_text(x):
    return unicodedata.normalize('NFKC',str(x or '')).replace('\u00a0',' ').strip()

def parse_sir(value):
    """Match an explicit complete AST result; does NOT match RBC, organisms or ERROR.
    The calling layer must additionally confirm that the row is an AST drug item.
    Conflicting annotations return None, never resolve a contradiction in favor of R.
    """
    t=normalize_text(value).upper()
    if re.fullmatch(r'[RSI]',t): return t
    if t in {'耐药','耐药(R)','耐药（R）'}: return 'R'
    if t in {'敏感','敏感(S)','敏感（S）'}: return 'S'
    if t in {'中介','中度敏感','中介(I)'}: return 'I'
    pattern=r'(?:[<>≤≥]=?\s*)?[+-]?(?:\d+(?:\.\d*)?|\.\d+)\s*(?:MM|MG/L|UG/ML|ΜG/ML|ΜG/L)?\s*\(\s*([RSI])\s*\)'
    m=re.fullmatch(pattern,t)
    return m.group(1) if m else None

def parse_timestamp(value, order='DMY'):
    """Explicit slash-date convention; no silent locale/dateutil inference."""
    t=normalize_text(value)
    if not t or t.upper() in {'NULL','NAN','NAT'}: return pd.NaT
    # ISO values exported by SQL are preferred.
    fmts=['%Y-%m-%d %H:%M:%S.%f','%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%M',
          '%Y-%m-%d','%Y/%m/%d %H:%M:%S','%Y/%m/%d %H:%M','%Y/%m/%d']
    t=t.replace('T',' ')
    fmts += (['%d/%m/%Y %H:%M:%S','%d/%m/%Y %H:%M','%d/%m/%Y'] if order=='DMY'
             else ['%m/%d/%Y %H:%M:%S','%m/%d/%Y %H:%M','%m/%d/%Y'])
    from datetime import datetime
    for f in fmts:
        try: return pd.Timestamp(datetime.strptime(t,f))
        except ValueError: pass
    return pd.NaT

def ensure_output(path):
    p=Path(path)
    if p.exists() and any(p.iterdir()): raise StudyError(f'Output directory is not empty: {p}. Use a new version/path.')
    p.mkdir(parents=True,exist_ok=True); return p

def cluster_weights(groups):
    s=pd.Series(groups,dtype=str); counts=s.value_counts()
    w=s.map(lambda g: 1.0/counts[g]).to_numpy(dtype=float)
    return w/w.mean()
