"""Preserved MIMIC R12 AST audit plus dispatch to the ZJ R13 text-only validator.
No ZJ drug-upgrade label path remains active. Outcome evidence never enters X.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from .common import StudyError, required, bool_value, read_csv

KEYS = ['patient_id', 'encounter_id', 'culture_id']


def primary_label(source: str, has_ast: bool, has_r: bool, new_drug96: bool) -> tuple[int, str]:
    if source != 'mimic':
        raise StudyError('This function is MIMIC-only. ZJ R13 uses source result text, never drug orders.')
    if has_r and not has_ast:
        raise StudyError('R cannot exist without an interpretable AST record')
    if has_r:
        return 1, 'LAB_R'
    if has_ast:
        return 0, 'LAB_NO_R'
    return 0, 'NO_AST_NO_TRIGGER'


def _timestamps(x: pd.Series) -> pd.Series:
    return pd.to_datetime(x, format='ISO8601', errors='coerce')

def _checked_flags(values: pd.Series, title: str) -> pd.Series:
    text=values.astype(str).str.strip().str.lower()
    if not text.isin({'1','0','true','false','t','f','yes','no','y','n'}).all():
        raise StudyError(title+' contains missing or unrecognised boolean values')
    return text.isin({'1','true','t','yes','y'})



def validate_day_labels(events: pd.DataFrame, reports: pd.DataFrame, members: pd.DataFrame,
                        matches: pd.DataFrame, orders: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    required(events,['event_id','source','patient_id','encounter_id','hospital_id','culture_date','t0',
                     'day_has_ast','day_has_r','y_lab_r','y_primary','med_proxy_96h','resistance_evidence_type'], 'daily events')
    required(members,['event_id','patient_id','encounter_id','hospital_id','culture_id','culture_t0'], 'culture_day_members')
    required(reports,['patient_id','encounter_id','report_id','has_r','has_sir'], 'final reports')
    if events.event_id.duplicated().any(): raise StudyError('Duplicate daily event_id')
    for key in ['y_lab_r','y_primary']:
        if not pd.to_numeric(events[key],errors='coerce').isin([0,1]).all():raise StudyError(key+' must be exactly 0 or 1; missing values are not silently recoded.')
    for key in ['day_has_ast','day_has_r','med_proxy_96h']:_checked_flags(events[key],key)
    if events.duplicated(['patient_id','hospital_id','culture_date']).any():
        raise StudyError('Natural-day key duplicated; same day is one event per hospital admission')
    if 'n_ast_conflicts' in events and pd.to_numeric(events.n_ast_conflicts,errors='coerce').fillna(0).gt(0).any():
        raise StudyError('Unresolved conflicting latest AST versions')
    ids=set(events.event_id)
    m=members.loc[members.event_id.isin(ids)].copy()
    if m.duplicated(KEYS).any(): raise StudyError('An original report is assigned more than once')
    if set(m.event_id)!=ids: raise StudyError('Missing day-member linkage')
    rp=reports.rename(columns={'report_id':'culture_id'})
    if rp.duplicated(KEYS).any(): raise StudyError('Original report keys duplicated')
    linked=m.merge(rp[KEYS+['has_r','has_sir']],on=KEYS,how='left',validate='one_to_one',indicator=True)
    if linked['_merge'].ne('both').any(): raise StudyError('A member report has no exact AST/report link')
    linked['culture_t0']=_timestamps(linked.culture_t0)
    if linked.culture_t0.isna().any(): raise StudyError('Member report has no exact culture timestamp')
    linked['has_r']=_checked_flags(linked.has_r,'report has_r')
    linked['has_sir']=_checked_flags(linked.has_sir,'report has_sir')
    if (linked.has_r&~linked.has_sir).any(): raise StudyError('R implies AST, violated in report data')
    a=linked.groupby('event_id').agg(first_t0=('culture_t0','min'),has_r=('has_r','any'),
                                   has_ast=('has_sir','any'),n_members=('culture_id','size'))
    ev=events.set_index('event_id',drop=False)
    for row in linked.itertuples():
        e=ev.loc[row.event_id]
        if row.patient_id!=e.patient_id or row.hospital_id!=e.hospital_id:
            raise StudyError('Day membership crosses patient/hospital admission')
        if row.culture_t0.date()!=pd.Timestamp(e.culture_date).date():
            raise StudyError('Day membership crosses midnight')
    t=_timestamps(ev.t0)
    if not (a.loc[ev.index,'first_t0'].to_numpy()==t.to_numpy()).all():
        raise StudyError('T0 is not the first culture on the selected natural day')
    if not a.loc[ev.index,'has_r'].eq(ev.day_has_r.map(bool_value)).all():
        raise StudyError('Daily R differs from original report evidence')
    if not a.loc[ev.index,'has_ast'].eq(ev.day_has_ast.map(bool_value)).all():
        raise StudyError('Daily AST availability differs from original report evidence')
    if not a.loc[ev.index,'has_r'].astype(int).eq(pd.to_numeric(ev.y_lab_r)).all():
        raise StudyError('y_lab_r is not the day-level documented R indicator')
    if 'n_day_reports' in ev and not a.loc[ev.index,'n_members'].eq(pd.to_numeric(ev.n_day_reports)).all():
        raise StudyError('Original report count differs from day membership')
    source=set(events.source)
    if len(source)!=1: raise StudyError('Audit one data source at a time')
    source=next(iter(source))
    if source!='mimic':raise StudyError('Use ZJ R13 raw-text validator, not the legacy AST validator')
    proxy_ids=set()
    if not matches.empty:raise StudyError('MIMIC must not contain treatment fallback evidence')
    rows=[]
    for eid,e in ev.iterrows():
        expected,reason=primary_label(source,bool(a.loc[eid,'has_ast']),bool(a.loc[eid,'has_r']),eid in proxy_ids)
        if int(float(e.y_primary))!=expected or e.resistance_evidence_type!=reason:
            raise StudyError('Primary endpoint/evidence source violates AST-first rules')
        if bool_value(e.med_proxy_96h)!=(eid in proxy_ids):
            raise StudyError('Medication proxy flag differs from original order evidence')
        rows.append({'event_id':eid,'y_primary_verified':expected,'evidence_verified':reason,
                     'n_members_verified':int(a.loc[eid,'n_members'])})
    return pd.DataFrame(rows)


def validate_export_labels(raw: str | Path, events: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    raw=Path(raw)
    if set(events.source)=={'zj'}:
        from .zj_text_labels import validate_zj_exports
        return validate_zj_exports(raw,events)
    names=['reports','culture_day_members','treatment_matches','target_orders']
    for name in names:
        if not (raw/(name+'.csv')).is_file(): raise StudyError(name+'.csv is required for independent day/proxy label checks')
    return validate_day_labels(events,*(read_csv(raw/(n+'.csv')) for n in names),cfg)
