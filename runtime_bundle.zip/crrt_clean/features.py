from __future__ import annotations
import numpy as np
import pandas as pd
from .common import StudyError, required
VITALS={'heart_rate','temperature','respiratory_rate','map','spo2'}

def clean_observations(obs, cfg):
    policy=cfg.get('observation_time_policy','measured_and_available')
    if policy not in {'measured_and_available','charttime_only'}:
        raise StudyError('Unknown observation_time_policy: '+str(policy))
    needed=['patient_id','encounter_id','feature','value','unit','measured_at','source_id']
    if policy=='measured_and_available': needed.append('available_at')
    required(obs,needed,'observations')
    d=obs.copy()
    if 'available_at' not in d.columns: d['available_at']=pd.NaT
    for c in ['measured_at','available_at']:
        d[c]=pd.to_datetime(d[c],format='ISO8601',errors='coerce')
    # M21 and observations.csv stay untouched. Preserve the original store/available
    # timestamp for audit; available_at below becomes the EFFECTIVE modelling clock.
    # Repeated cleaning must not overwrite an already preserved raw timestamp.
    if 'available_at_raw' not in d.columns:
        d['available_at_raw']=d['available_at'].copy()
    if policy=='charttime_only':
        d['available_at']=d['measured_at']
    d['observation_time_policy']=policy
    d['value']=pd.to_numeric(d.value,errors='coerce')
    d['priority']=pd.to_numeric(d.get('priority',pd.Series(10,index=d.index)),errors='coerce').fillna(100)
    valid=d.feature.isin(cfg['features'])&d.value.notna()&np.isfinite(d.value)&d.measured_at.notna()&d.available_at.notna()
    valid &= d.available_at.ge(d.measured_at)
    for f in cfg['features']:
        take=d.feature.eq(f); lo,hi=cfg['plausible_ranges'][f]
        valid &= ~take | (d.value.between(lo,hi) & d.unit.eq(cfg['unit_contract'][f]))
    rejected=d.loc[~valid].copy()
    # Exact duplicates are removed; revisions at distinct available_at remain time-aware.
    d=d.loc[valid].sort_values(['priority','source_id'],kind='stable').drop_duplicates(['patient_id','encounter_id','feature','measured_at','available_at','value','unit'])
    return d,rejected

def _dedup_at_time(d):
    return d.sort_values(['measured_at','priority','available_at','source_id'],ascending=[True,True,False,True]).drop_duplicates('measured_at',keep='first')

def static_vector(event,cfg):
    """Fixed contract shared by summaries, neural static branch, and the web.
    Only the requested static variables are admitted. Audit columns NEVER enter X.
    Admission/discharge-derived history is intentionally retrospective.
    """
    def num(key):
        v=event.get(key,np.nan)
        try:
            if str(v).lower() in {'true','t'}: return 1.0
            if str(v).lower() in {'false','f'}: return 0.0
            return float(v) if str(v).strip() else np.nan
        except (TypeError,ValueError): return np.nan
    sex=str(event.get('sex','')).strip().upper()
    tab={'age':num('age'),'sex_female':float(sex in {'F','FEMALE','女'}),
         'sex_unknown':float(sex not in {'F','FEMALE','女','M','MALE','男'})}
    for f in cfg['history_fields']+['antibiotic_exposure_7d','carbapenem_exposure_7d','invasive_ventilation_t0']:
        v=num(f)
        if np.isfinite(v) and v not in (0,1): raise StudyError(f'{f} must be 0, 1, or missing')
        tab[f]=0.0 if f=='invasive_ventilation_t0' and not np.isfinite(v) else v
    n=num('antibiotic_classes_7d')
    if np.isfinite(n) and (n<0 or n>100 or n!=int(n)): raise StudyError('Invalid antibiotic_classes_7d')
    tab['antibiotic_classes_7d']=n
    site=str(event.get('specimen_site','unknown')).strip().lower()
    if site not in cfg['site_categories']: raise StudyError('Unknown specimen_site category: '+site)
    for category in cfg['site_categories']: tab['specimen_site_'+category]=float(site==category)
    a=tab['antibiotic_exposure_7d'];c=tab['carbapenem_exposure_7d']
    if a==0 and ((np.isfinite(n) and n>0) or c==1): raise StudyError('Antibiotic exposure contradicts class/carbapenem fields')
    if a==1 and n==0: raise StudyError('Positive antibiotic exposure with zero classes')
    return {f:tab[f] for f in cfg['static_numeric']}

def event_features(obs,event,cfg):
    """All models use exactly the same pre-T0 records. Summary deltas use real
    observations, NOT forward-filled hourly duplicates. Future MEASUREMENTS are
    always excluded. In charttime_only mode, late reports may be used retrospectively;
    available_at is the effective clock set by clean_observations, not raw storetime.
    """
    t0=pd.Timestamp(event['t0']); hours=cfg['hours']; bh=cfg['bin_hours']
    if hours%bh: raise StudyError('hours must be divisible by bin_hours')
    nbin=hours//bh; fs=cfg['features']; start=t0-pd.Timedelta(hours=hours)
    eligible_start=start
    if 'start_time' in event:
        icu_start=pd.to_datetime(event['start_time'],format='ISO8601',errors='coerce')
        if pd.isna(icu_start) or t0<icu_start:raise StudyError('T0 is before or lacks the anchor ICU interval start.')
        eligible_start=max(start,icu_start)
    if 'end_time' in event:
        icu_end=pd.to_datetime(event['end_time'],format='ISO8601',errors='coerce')
        if pd.isna(icu_end) or t0>=icu_end:raise StudyError('T0 must be strictly before the anchor ICU interval end.')
    d=obs.loc[obs.measured_at.ge(eligible_start)&obs.measured_at.le(t0)&obs.available_at.le(t0)].copy()
    values=np.full((nbin,len(fs)),np.nan,dtype=np.float32)
    fresh=np.zeros_like(values); ages=np.full_like(values,float(hours)); tab=static_vector(event,cfg)
    for j,f in enumerate(fs):
        g=d.loc[d.feature.eq(f)].copy(); u=_dedup_at_time(g)
        vals=u.value.to_numpy(dtype=float); n=len(u)
        row={k:np.nan for k in cfg['summary_stats']}; row['n_times']=n
        if n:
            row.update(last=float(vals[-1]),median=float(np.median(vals)),min=float(vals.min()),max=float(vals.max()))
            row['std']=float(np.std(vals,ddof=0)) if n>=2 else np.nan
        if n>=2:
            x=(u.measured_at-u.measured_at.iloc[0]).dt.total_seconds().to_numpy()/3600
            row['delta']=float(vals[-1]-vals[0]); row['slope_per_hour']=float(np.polyfit(x,vals,1)[0]) if np.ptp(x)>0 else np.nan
        # Difference of two specified six-hour windows, not relative-percent division.
        recent=u.loc[u.measured_at.gt(t0-pd.Timedelta(hours=6)),'value']
        earlier=u.loc[u.measured_at.gt(t0-pd.Timedelta(hours=12))&u.measured_at.le(t0-pd.Timedelta(hours=6)),'value']
        if len(recent) and len(earlier): row['late6_minus_early6']=float(recent.mean()-earlier.mean())
        for k in cfg['summary_stats']: tab[f+'__'+k]=row[k]
        ttl=cfg['vital_ttl_hours'] if f in VITALS else cfg['lab_ttl_hours']
        if len(g):
            # Sort once per channel, then perform all hourly availability tests in NumPy.
            gg=g.sort_values(['measured_at','priority','available_at','source_id'],ascending=[False,True,False,True])
            measured=gg.measured_at.to_numpy(dtype='datetime64[ns]').astype('int64')
            available=gg.available_at.to_numpy(dtype='datetime64[ns]').astype('int64')
            vv=gg.value.to_numpy(dtype=float)
            hour_ns=3600*10**9
            ends=pd.Timestamp(start).value+(np.arange(nbin)+1)*bh*hour_ns
            valid=(measured[None,:]<=ends[:,None])&(available[None,:]<=ends[:,None])&(measured[None,:]>=ends[:,None]-ttl*hour_ns)
            has=valid.any(axis=1);q=np.argmax(valid,axis=1)
            values[has,j]=vv[q[has]]
            left=ends-bh*hour_ns
            new_report=valid&((available[None,:]>left[:,None])|((np.arange(nbin)[:,None]==0)&(available[None,:]==left[:,None])))
            fresh[:,j]=new_report.any(axis=1)
            ages[has,j]=np.clip((ends[has]-measured[q[has]])/hour_ns,0,hours)
    return tab,values,fresh,ages
