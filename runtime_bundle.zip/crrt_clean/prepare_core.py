from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .common import *
from .features import clean_observations
from .features_fast import event_features

LABELS={'y_primary'}

def prepare(raw, config, output, approval=None, demo=False):
    cfg=load_json(config); cfg.setdefault('observation_time_policy','measured_and_available')
    out=ensure_output(output); raw=Path(raw)
    if cfg['endpoint'] not in LABELS: raise StudyError('Use y_primary from the source-specific final culture-day SQL table.')
    ev=read_csv(raw/'events.csv'); obs=read_csv(raw/'observations.csv')
    required(ev,cfg['static_input_fields'],'event baseline variables')
    if cfg.get('event_selection')!='natural_day': raise StudyError('Use R12 SQL natural-day output; do not aggregate again in Python.')
    required(ev,['event_id','source','patient_id','encounter_id','t0','event_source','exposure_tier','age','sex',cfg['endpoint']],'events')
    if not demo:
        required(ev,['start_time','end_time'],'anchor ICU interval')
        log=read_csv(raw/'run_log.csv')
        required(log,['step'],'run_log')
        rows=log.loc[log.step.eq('local_review')]
        if rows.empty: raise StudyError('Missing exported local_review stage. Review extraction mappings before using real data.')
        ap={'provenance':'inherited_SQL_local_review_NOT_new_clinical_review',
            'exported_stage_records':rows.to_dict('records')}
    else:ap={'software_fixture_only':True}
    sources=set(ev.source)
    if len(sources)!=1 or not sources.issubset({'mimic','zj'}):raise StudyError('Prepare one source at a time, never pool MIMIC and ZJ before validation.')
    source=next(iter(sources)); counts={'source':source,'raw_event_rows':len(ev),'observation_time_policy':cfg['observation_time_policy']}
    if source=='zj':
        ev=ev.loc[ev.event_source.eq(cfg['event_source_zj'])&ev.exposure_tier.eq(cfg['exposure_tier_zj'])].copy()
        counts['selected_exposure_tier']=cfg['exposure_tier_zj']
        counts['tier_is_confirmed_crrt_treatment']=False if cfg['exposure_tier_zj']=='D_ANY_RENAL_KEYWORD_AUDIT' else None
    counts['after_source_and_tier']=len(ev)
    if ev.empty:raise StudyError('No events in the selected source/tier. Check R12 SQL output before modelling.')
    if ev.event_id.duplicated().any():raise StudyError('Duplicate event_id; do not treat repeated AST rows as cultures.')
    from .labels import validate_export_labels
    validate_export_labels(raw,ev,cfg)
    forbidden=set(cfg['post_t0_fields_forbidden_in_X'])
    if forbidden.intersection(cfg['static_input_fields']+cfg['static_numeric']):
        raise StudyError('Post-T0 outcome evidence has entered the feature whitelist')
    ev['t0']=pd.to_datetime(ev.t0,format='ISO8601',errors='coerce')
    ev['age']=pd.to_numeric(ev.age,errors='coerce')
    ev['label']=pd.to_numeric(ev[cfg['endpoint']],errors='coerce')
    keep=ev.t0.notna()&ev.label.isin([0,1])
    if cfg['require_age18']:keep &= ev.age.ge(18)&np.isfinite(ev.age)
    if cfg['require_crrt_before_t0']:
        required(ev,['renal_before_t0'],'CRRT prior evidence');keep &= ev.renal_before_t0.map(bool_value)
    ev.loc[~keep].to_csv(out/'excluded_events.csv',index=False,encoding='utf-8-sig')
    ev=ev.loc[keep].sort_values(['patient_id','encounter_id','t0','event_id']).reset_index(drop=True)
    counts['after_time_age_and_label']=len(ev)
    ev.groupby('resistance_evidence_type').agg(culture_days=('event_id','size'),patients=('patient_id','nunique'),positive_days=('label','sum')).reset_index().to_csv(out/'label_evidence_summary.csv',index=False)
    counts['lab_r_positive_days']=int(pd.to_numeric(ev.y_lab_r).sum())
    counts['drug_only_positive_days']=0
    if source=='zj':
        counts['literal_r_positive_days']=int(ev.y_text_r.map(bool_value).sum())
        counts['conservative_positive_days']=int(ev.y_species_conservative.map(bool_value).sum())
    if ev.empty:raise StudyError('No adult, timed, labelled events remain. Inspect excluded_events.csv.')
    # Patient keys identify the same person across ALL admissions.
    ev['group_id']=source+':'+ev.patient_id.astype(str)
    ev=ev.reset_index(drop=True);counts['final_events']=len(ev)
    keys=set(zip(ev.patient_id,ev.encounter_id));obs=obs.loc[[k in keys for k in zip(obs.patient_id,obs.encounter_id)]].copy()
    n_raw_observations=len(obs)
    obs,bad=clean_observations(obs,cfg)
    bad.groupby('feature',dropna=False).size().rename('rejected_rows').reset_index().to_csv(out/'observation_rejection_summary.csv',index=False)
    bad.to_csv(out/'observation_rejections.csv',index=False,encoding='utf-8-sig')
    missing=set(cfg['features'])-set(obs.feature)
    if missing:raise StudyError(f'Entire source channels absent or invalid: {sorted(missing)}. Revise the shared contract BEFORE model fitting; no zero-filled fake external channels.')
    og={k:g.sort_values('measured_at') for k,g in obs.groupby(['patient_id','encounter_id'],sort=False)}
    empty=obs.iloc[0:0];tables=[];values=[];masks=[];ages=[]
    for event_number,(_,e) in enumerate(ev.iterrows(),1):
        g=og.get((e.patient_id,e.encounter_id),empty)
        left=g.measured_at.searchsorted(e.t0-pd.Timedelta(hours=cfg['hours']),side='left')
        right=g.measured_at.searchsorted(e.t0,side='right')
        tab,v,m,a=event_features(g.iloc[left:right],e,cfg)
        tables.append(tab);values.append(v);masks.append(m);ages.append(a)
        if event_number % cfg.get('progress_every',250)==0 or event_number==len(ev): print(f'Prepared {event_number}/{len(ev)} culture events',flush=True)
    tab=pd.DataFrame(tables)
    if len(values)==0:raise StudyError('No events after selection.')
    # For truly unavailable summaries (one observation), delta/std/slope remain NaN.
    # Do not disguise a completely unavailable external variable as an observed feature.
    audit=[]
    for f in cfg['static_numeric']:
        audit.append({'feature':f,'events':len(tab),'observed':int(tab[f].notna().sum()),'missing_fraction':float(tab[f].isna().mean()),'unique_observed':int(tab[f].nunique())})
    pd.DataFrame(audit).to_csv(out/'static_quality.csv',index=False)
    absent=[f for f in cfg['history_fields']+['antibiotic_exposure_7d','antibiotic_classes_7d','carbapenem_exposure_7d','invasive_ventilation_t0'] if tab[f].isna().all()]
    if absent: raise StudyError('Entire static variables unavailable: '+str(absent)+'. Review local extraction; do not silently replace by zeros.')
    tab.insert(0,'event_id',ev.event_id)
    tab.to_csv(out/'features.csv',index=False,encoding='utf-8-sig')
    ev.to_csv(out/'events.csv',index=False,encoding='utf-8-sig')
    values=np.stack(values);masks=np.stack(masks);ages=np.stack(ages)
    unavailable=[f for j,f in enumerate(cfg['features']) if not np.isfinite(values[:,:,j]).any()]
    if unavailable:raise StudyError('No usable pre-T0 values for entire channels: '+str(unavailable))
    np.savez_compressed(out/'sequences.npz',event_ids=ev.event_id.to_numpy(dtype=str),features=np.array(cfg['features']),values=values,mask=masks,age=ages)
    cov=[]
    for j,f in enumerate(cfg['features']):
        for k in range(values.shape[1]):cov.append({'feature':f,'hour_end_relative_t0':-cfg['hours']+(k+1)*cfg['bin_hours'],'value_coverage':float(np.isfinite(values[:,k,j]).mean()),'new_report_coverage':float(masks[:,k,j].mean())})
    # Legacy new_report_coverage column denotes NEW MEASUREMENTS in charttime_only mode.
    for row in cov:
        row['mask_clock']='measured_at' if cfg['observation_time_policy']=='charttime_only' else 'available_at'
    pd.DataFrame(cov).to_csv(out/'hourly_coverage.csv',index=False)
    summary=[]
    for f in cfg['features']:
        n=tab[f+'__n_times'];summary.append({'feature':f,'events':len(n),'at_least_one':int((n>=1).sum()),'at_least_two_real_times':int((n>=2).sum()),'coverage_24h_pct':float(100*(n>=1).mean()),'coverage_2plus_pct':float(100*(n>=2).mean()),'median_real_times_all_events':float(n.median()),'median_real_times_when_observed':float(n[n>=1].median()),'p_missing':float((n==0).mean())})
    pd.DataFrame(summary).to_csv(out/'sequence_quality.csv',index=False)
    counts.update(patients=int(ev.group_id.nunique()),encounters=int(ev[['patient_id','encounter_id']].drop_duplicates().shape[0]),positive_events=int(ev.label.sum()),positive_patients=int(ev.loc[ev.label.eq(1),'group_id'].nunique()),rejected_observation_rows=len(bad),raw_observations_in_selected_visits=n_raw_observations,clean_observation_rows=len(obs),all_channels_empty_events=int(np.all(~np.isfinite(values),axis=(1,2)).sum()))
    save_json(out/'counts.json',counts)
    contract={k:cfg[k] for k in ['endpoint','hours','bin_hours','features','static_numeric','summary_stats','unit_contract','event_selection','signature_boundary','day_key','label_policy_by_source','require_crrt_before_t0','require_age18','history_policy','history_fields','site_categories','antibiotic_evidence','ventilation_policy']}
    contract['observation_time_policy']=cfg['observation_time_policy']
    for key in ['plausible_ranges','vital_ttl_hours','lab_ttl_hours','vent_lookback_hours','antibiotic_lookback_hours','ventilation_policy']:contract[key]=cfg[key]
    contract['history_window_boundary']='MAX_T0_MINUS24H_ANCHOR_ICU_START_TO_T0_END_EXCLUSIVE_ICU'
    save_json(out/'manifest.json',{'source':source,'contract':contract,'contract_hash':signature(contract),'demo_only':demo,'approval':ap,'config':cfg,'counts':counts,'label_ascertainment':cfg['label_policy_by_source'][source],'scope_warning':'MIMIC uses recorded CRRT procedures. ZJ D tier includes ANY renal-related keyword such as supplies/monitoring/access/HD and is NOT evidence-confirmed CRRT. Retrospective ever-exposure membership can be after T0. ZJ ICU scope uses reviewed DR admission/discharge intervals. MIMIC uses laboratory R records; ZJ uses literal ASCII r/R in final linked report results OR conservative culture species/phenotype. No drug-upgrade endpoint. External outcomes are differently ascertained; not strict same-reference-standard validation.'})
    print(json.dumps(counts,ensure_ascii=False))

def load_prepared(folder):
    p=Path(folder);meta=load_json(p/'manifest.json')
    if signature(meta['contract'])!=meta['contract_hash']:raise StudyError('Prepared manifest contract hash is invalid.')
    ev=read_csv(p/'events.csv');labels=pd.to_numeric(ev.label,errors='coerce')
    if not labels.isin([0,1]).all():raise StudyError('Prepared labels must be binary; labels are not rounded or filled.')
    ev['label']=labels.astype(int);ev['age']=pd.to_numeric(ev.age,errors='coerce')
    if ev.empty or ev.event_id.duplicated().any():raise StudyError('Prepared events are empty or have duplicate event IDs.')
    if ev.group_id.eq('').any():raise StudyError('Prepared events have a missing patient group ID.')
    ev['t0']=pd.to_datetime(ev.t0,format='ISO8601',errors='raise')
    f=pd.read_csv(p/'features.csv',dtype={'event_id':str},encoding='utf-8-sig',float_precision='round_trip')
    if list(ev.event_id)!=list(f.event_id):raise StudyError('Feature/event order mismatch')
    cfg=meta['config']
    expected=(len(ev),cfg['hours']//cfg['bin_hours'],len(cfg['features']))
    with np.load(p/'sequences.npz',allow_pickle=False) as z:
        if list(z['event_ids'])!=list(ev.event_id):raise StudyError('Sequence/event order mismatch')
        if list(z['features'])!=cfg['features']:raise StudyError('Sequence feature order differs from the frozen contract.')
        arrays=tuple(z[k].astype(np.float32) for k in ['values','mask','age'])
    if any(a.shape!=expected for a in arrays):raise StudyError('Sequence dimensions differ from the frozen contract.')
    if np.isinf(arrays[0]).any() or not np.isin(arrays[1],[0,1]).all() or not np.isfinite(arrays[2]).all():raise StudyError('Invalid sequence values, observation masks, or time-since-observation values.')
    if (arrays[2]<0).any() or (arrays[2]>cfg['hours']).any():raise StudyError('Observation age is outside the permitted history window.')
    return ev,f.drop(columns='event_id'),arrays,meta
