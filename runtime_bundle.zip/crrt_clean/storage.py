from __future__ import annotations
import hashlib,json,platform,sys,os,time
from pathlib import Path
from datetime import datetime,timezone
from importlib.metadata import version,PackageNotFoundError
from contextlib import contextmanager
from .common import StudyError,save_json,load_json,signature
ROOT=Path(os.environ.get('CRRT_WEB_ROOT',Path(__file__).resolve().parents[1])).resolve()

def hash_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()

def file_map(folder,names=None):
    folder=Path(folder)
    files=[folder/n for n in names] if names else sorted(p for p in folder.rglob('*') if p.is_file() and p.name not in ['COMPLETE.json','LOCK'])
    return {p.relative_to(folder).as_posix():hash_file(p) for p in files}

def environment():
    packages={}
    for n in ['numpy','pandas','scipy','scikit-learn','xgboost','torch','joblib','matplotlib','pytest','threadpoolctl','lightgbm','shap','statsmodels','python-pptx','pillow']:
        try:packages[n]=version(n)
        except PackageNotFoundError:packages[n]='NOT_INSTALLED'
    return {'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'packages':packages,'cpu_count':os.cpu_count()}

def code_hash():
    return signature(file_map(ROOT/'crrt_clean',names=[p.name for p in sorted((ROOT/'crrt_clean').glob('*.py')) if p.name not in {'plots.py','explain.py'}]))

def relative(path):
    try:return str(Path(path).resolve().relative_to(ROOT))
    except ValueError:return str(path)

def require_finished(folder,expected=None):
    folder=Path(folder);p=folder/'COMPLETE.json'
    if not p.exists():raise StudyError('Incomplete stage: '+relative(folder))
    meta=load_json(p)
    if expected is not None and meta['fingerprint']!=expected:raise StudyError('Inputs/settings changed for '+relative(folder)+'. Use a clean output project/version; do not overwrite provenance.')
    for n,h in meta['files'].items():
        if not (folder/n).is_file() or hash_file(folder/n)!=h:raise StudyError('Cached file changed: '+relative(folder/n))
    return meta

def completed(folder,fingerprint):
    p=Path(folder)
    if not p.exists():return False
    if (p/'COMPLETE.json').exists():
        require_finished(p,fingerprint);print('REUSE VERIFIED: '+relative(p),flush=True);return True
    return False

def begin_stage(folder,retry=False):
    p=Path(folder)
    if p.exists() and any(p.iterdir()):
        if not retry:raise StudyError('Partial output exists: '+relative(p)+'. Inspect FAILURE.json; use --retry-incomplete only after diagnosis.')
        backup=p.with_name(p.name+'.incomplete_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));p.rename(backup)
    p.mkdir(parents=True,exist_ok=True);return p

def finish_stage(folder,fingerprint,extra=None):
    meta={'fingerprint':fingerprint,'finished_utc':datetime.now(timezone.utc).isoformat(),'files':file_map(folder)}
    if extra:meta.update(extra)
    save_json(Path(folder)/'COMPLETE.json',meta)
    return meta

@contextmanager
def project_lock():
    out=ROOT/'outputs';out.mkdir(exist_ok=True);p=out/'RUNNING.lock'
    try:fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise StudyError('Another command may be running. Do not run concurrent writers. If previous process ended, remove outputs/RUNNING.lock manually.')
    os.write(fd,(str(os.getpid())+'\n').encode());os.close(fd)
    try:yield
    finally:p.unlink(missing_ok=True)
