"""Unchanged R42 estimators except removal of HistGB registration."""
from __future__ import annotations
import copy
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score
from threadpoolctl import threadpool_limits
from .common import StudyError, cluster_weights, save_json
from .network import SEQUENCE_MODELS, feature_columns, preprocessor, SequenceScaler, make_network, torch_seed, net_logits

MODELS=('LR_trend', 'XGB_trend', 'LightGBM_trend', 'GRU', 'LSTM', 'TCN', 'Transformer')

def training_weights(y, groups, patient_equal=True, class_balance='none'):
    y=np.asarray(y,int)
    if set(np.unique(y))!={0,1}: raise StudyError('Training requires both outcome classes.')
    w=cluster_weights(groups) if patient_equal else np.ones(len(y),float)
    ratio=float(w[y==0].sum()/w[y==1].sum())
    if class_balance=='sqrt': w=w*np.where(y==1,np.sqrt(ratio),1.)
    elif class_balance=='balanced': w=w*np.where(y==1,ratio,1.)
    elif class_balance!='none': raise StudyError('Invalid class_balance')
    return w/w.mean()

def build_estimator(name,p,seed,jobs):
    p=copy.deepcopy(p)
    if name=='LR_trend':return LogisticRegression(**p,random_state=seed)
    if name=='XGB_trend':
        from xgboost import XGBClassifier
        return XGBClassifier(**p,random_state=seed,n_jobs=jobs)
    if name=='LightGBM_trend':
        from lightgbm import LGBMClassifier
        return LGBMClassifier(**p,random_state=seed,n_jobs=jobs)
    raise StudyError('Unknown tabular model: '+name)

def fit_full(name,X,y,groups,arrays,cfg,model_cfg,runtime):
    if name not in MODELS:raise StudyError('Unknown model')
    y=np.asarray(y,int);groups=np.asarray(groups,str)
    if len(X)!=len(y) or any(len(a)!=len(y) for a in arrays):raise StudyError('Training row mismatch')
    spec=copy.deepcopy(model_cfg['spec']);p=spec['params'];seed=int(model_cfg['seed']);jobs=int(runtime['threads'])
    columns=feature_columns(name,cfg)
    if set(columns)&set(cfg['post_t0_fields_forbidden_in_X']):raise StudyError('Forbidden outcome input')
    w=training_weights(y,groups,spec['patient_equal_weight'],spec['class_balance'])
    pp=preprocessor();static=pp.fit_transform(X[columns])
    bundle={'name':name,'parameter_id':model_cfg['parameter_id'],'columns':columns,'preprocessor':pp,
            'spec':spec,'seed':seed,'fit_event_count':len(y),'fit_patient_count':len(set(groups)),
            'zero_weight_rows':int((w<=0).sum()),'cfg':copy.deepcopy(cfg),'calibration':'none',
            'internal_test_events':0,'calibration_events':0,'patient_equal_weight':spec['patient_equal_weight']}
    if name not in SEQUENCE_MODELS:
        model=build_estimator(name,p,seed,jobs)
        with threadpool_limits(limits=jobs):model.fit(static,y,sample_weight=w)
        bundle.update(kind='tabular',estimator=model)
        return bundle
    import torch
    from torch.utils.data import TensorDataset,DataLoader
    torch_seed(seed);torch.set_num_threads(jobs)
    net_cfg=dict(cfg,**{k:v for k,v in p.items() if k!='epochs'})
    ss=SequenceScaler().fit(arrays[0]);seq=ss.transform(*arrays,cfg['hours']);static=static.astype(np.float32)
    net=make_network(name,seq.shape[-1],static.shape[-1],net_cfg)
    ds=TensorDataset(torch.from_numpy(seq),torch.from_numpy(static),torch.tensor(y,dtype=torch.float32),torch.tensor(w,dtype=torch.float32))
    dl=DataLoader(ds,batch_size=p['batch_size'],shuffle=True,num_workers=0,generator=torch.Generator().manual_seed(seed))
    opt=torch.optim.AdamW(net.parameters(),lr=p['learning_rate'],weight_decay=p['weight_decay'])
    criterion=torch.nn.BCEWithLogitsLoss(reduction='none');history=[]
    for epoch in range(1,int(p['epochs'])+1):
        net.train();total=0.;n=0
        for sq,st,target,wt in dl:
            opt.zero_grad();loss=(criterion(net(sq,st),target)*wt).mean()
            if not torch.isfinite(loss):raise StudyError(name+': nonfinite training loss')
            loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5.);opt.step()
            total+=float(loss.detach())*len(target);n+=len(target)
        row={'epoch':epoch,'train_weighted_loss':total/n}
        # Preserve old fixed-epoch training. Logging cannot select an epoch.
        if epoch==1 or epoch==p['epochs'] or epoch%int(runtime['epoch_log_every'])==0:
            pr=expit(net_logits(net,seq,static))
            row.update(train_apparent_auroc=float(roc_auc_score(y,pr)),train_apparent_ap=float(average_precision_score(y,pr)))
            print(f'{name}: epoch {epoch}/{p["epochs"]}, train loss={total/n:.6f}, apparent AUC={row["train_apparent_auroc"]:.6f}',flush=True)
        history.append(row)
    net.eval()
    bundle.update(kind='sequence',network=net,sequence_scaler=ss,cfg=net_cfg,n_channels=seq.shape[-1],n_static=static.shape[-1],epochs=p['epochs'],history=history)
    return bundle

def predict_raw(bundle,X,arrays,threads=2):
    t=bundle['preprocessor'].transform(X[bundle['columns']])
    with threadpool_limits(limits=threads):
        if bundle['kind']=='tabular':p=bundle['estimator'].predict_proba(t)[:,1]
        else:
            import torch
            torch.set_num_threads(threads)
            sq=bundle['sequence_scaler'].transform(*arrays,bundle['cfg']['hours'])
            p=expit(net_logits(bundle['network'],sq,t.astype(np.float32)))
    p=np.asarray(p,float)
    if not np.isfinite(p).all() or ((p<0)|(p>1)).any():raise StudyError('Invalid predicted probabilities')
    return p

def save_bundle(bundle,folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    b={k:v for k,v in bundle.items() if k!='network'}
    if b['kind']=='sequence':
        import torch
        torch.save(bundle['network'].state_dict(),folder/'weights.pt')
        pd.DataFrame(bundle['history']).to_csv(folder/'training_history.csv',index=False)
    joblib.dump(b,folder/'model.joblib')
    save_json(folder/'fit_audit.json',{k:b[k] for k in ['name','parameter_id','seed','fit_event_count','fit_patient_count','zero_weight_rows','internal_test_events','calibration_events','calibration','spec','columns']})

def load_bundle(folder):
    # Only call after project-local SHA256 validation; never load unknown downloads.
    folder=Path(folder);b=joblib.load(folder/'model.joblib')
    if b['kind']=='sequence':
        import torch
        net=make_network(b['name'],b['n_channels'],b['n_static'],b['cfg'])
        net.load_state_dict(torch.load(folder/'weights.pt',map_location='cpu',weights_only=True))
        net.eval();b['network']=net
    return b
