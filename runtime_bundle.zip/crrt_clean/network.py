from __future__ import annotations
import random
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from .common import StudyError
SEQUENCE_MODELS={'GRU','LSTM','TCN','Transformer'}
def feature_columns(name,cfg):
    if name in SEQUENCE_MODELS:return list(cfg['static_numeric'])
    stats=['last'] if name=='LR_latest' else cfg['summary_stats']
    return list(cfg['static_numeric'])+[f+'__'+s for f in cfg['features'] for s in stats]

def preprocessor():
    return Pipeline([('fill',SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True)),('scale',StandardScaler())])

class SequenceScaler:
    def fit(self,values):
        flat=values.reshape(-1,values.shape[-1]);med=[]
        for j in range(flat.shape[1]):
            a=flat[:,j];good=a[np.isfinite(a)];med.append(float(np.median(good)) if len(good) else 0.)
        self.median=np.array(med);filled=np.where(np.isfinite(flat),flat,self.median)
        self.mean=filled.mean(axis=0);self.std=filled.std(axis=0);self.std[self.std<1e-6]=1.
        return self
    def transform(self,values,mask,age,hours=24):
        a=np.where(np.isfinite(values),values,self.median);a=(a-self.mean)/self.std
        return np.concatenate([a,mask,np.clip(age,0,hours)/hours],axis=-1).astype(np.float32)

def make_network(name,n_channels,n_static,cfg):
    import torch
    from torch import nn
    class Net(nn.Module):
        def __init__(self):
            super().__init__();self.name=name;hidden=cfg['hidden_size']
            if name=='GRU':self.rnn=nn.GRU(n_channels,hidden,batch_first=True)
            elif name=='LSTM':self.rnn=nn.LSTM(n_channels,hidden,batch_first=True)
            elif name=='TCN':
                self.convs=nn.ModuleList([nn.Conv1d(n_channels if i==0 else hidden,hidden,3,dilation=2**i) for i in range(4)])
            elif name=='Transformer':
                import math
                self.input_projection=nn.Linear(n_channels,hidden)
                # Independently initialized layers, not repeated copies of a single layer.
                self.attention_layers=nn.ModuleList([
                    nn.TransformerEncoderLayer(d_model=hidden,nhead=cfg['num_heads'],
                      dim_feedforward=cfg['ff_dim'],dropout=cfg['dropout'],
                      activation='gelu',batch_first=True,norm_first=False)
                    for _ in range(cfg['num_layers'])])
                length=int(cfg['hours']/cfg['bin_hours'])
                position=torch.arange(length,dtype=torch.float32).unsqueeze(1)
                div=torch.exp(torch.arange(0,hidden,2,dtype=torch.float32)*(-math.log(10000.0)/hidden))
                pe=torch.zeros(length,hidden);pe[:,0::2]=torch.sin(position*div)
                pe[:,1::2]=torch.cos(position*div)
                self.register_buffer('positional_encoding',pe.unsqueeze(0))
                self.final_norm=nn.LayerNorm(hidden)
            else:raise StudyError('Unknown sequence architecture')
            self.dropout=nn.Dropout(cfg['dropout']);self.static=nn.Sequential(nn.Linear(n_static,8),nn.ReLU())
            self.head=nn.Sequential(nn.Linear(hidden+8,8),nn.ReLU(),nn.Dropout(cfg['dropout']),nn.Linear(8,1))
        def forward(self,seq,static):
            if self.name=='TCN':
                z=seq.transpose(1,2)
                for i,conv in enumerate(self.convs):z=self.dropout(torch.relu(conv(nn.functional.pad(z,(2*2**i,0)))))
                h=z[:,:,-1]
            elif self.name=='Transformer':
                z=self.input_projection(seq)+self.positional_encoding[:,:seq.shape[1],:]
                for layer in self.attention_layers:z=layer(z)
                h=self.final_norm(z)[:,-1,:]
            else:z,_=self.rnn(seq);h=z[:,-1,:]
            return self.head(torch.cat([h,self.static(static)],dim=1)).squeeze(-1)
    return Net()

def torch_seed(seed):
    import torch
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)

def net_logits(net,seq,static):
    import torch
    net.eval();out=[]
    with torch.no_grad():
        for i in range(0,len(seq),256):out.append(net(torch.from_numpy(seq[i:i+256]),torch.from_numpy(static[i:i+256])).cpu().numpy())
    return np.concatenate(out)
