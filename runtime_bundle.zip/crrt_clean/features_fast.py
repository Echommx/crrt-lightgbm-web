"""NumPy implementation of the preserved event_features contract.

Ordering, windows, deduplication, masks, age, TTL and summary definitions are
identical to features.py; that reference remains available for equivalence tests.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from .common import StudyError
from .features import static_vector,VITALS

HOUR_NS=3600*10**9

def event_features(obs,event,cfg):
    t0=pd.Timestamp(event['t0']);hours=cfg['hours'];bh=cfg['bin_hours']
    if hours%bh:raise StudyError('hours must be divisible by bin_hours')
    t=t0.value;start=t-hours*HOUR_NS;lo=start
    if 'start_time' in event:
        it=pd.to_datetime(event['start_time'],format='ISO8601',errors='coerce')
        if pd.isna(it) or t0<it:raise StudyError('T0 is before or lacks the anchor ICU interval start.')
        lo=max(lo,it.value)
    if 'end_time' in event:
        ot=pd.to_datetime(event['end_time'],format='ISO8601',errors='coerce')
        if pd.isna(ot) or t0>=ot:raise StudyError('T0 must be strictly before the anchor ICU interval end.')
    nbin=hours//bh;fs=cfg['features'];tab=static_vector(event,cfg)
    v=np.full((nbin,len(fs)),np.nan,dtype=np.float32);m=np.zeros_like(v);age=np.full_like(v,float(hours))
    meas=obs.measured_at.to_numpy(dtype='datetime64[ns]').astype('int64');avail=obs.available_at.to_numpy(dtype='datetime64[ns]').astype('int64')
    valid=(meas>=lo)&(meas<=t)&(avail<=t)
    meas=meas[valid];avail=avail[valid]
    f=obs.feature.to_numpy()[valid];val=obs.value.to_numpy(dtype=float)[valid]
    priority=obs.priority.to_numpy(dtype=float)[valid];sid=obs.source_id.to_numpy(dtype=str)[valid]
    ends=start+(np.arange(nbin)+1)*bh*HOUR_NS;left=ends-bh*HOUR_NS
    for j,feature in enumerate(fs):
        take=np.flatnonzero(f==feature);row={k:np.nan for k in cfg['summary_stats']}
        if len(take):
            # same measured_at/priority/available_at/source_id lexicographic order
            order=np.lexsort((sid[take],-avail[take],priority[take],meas[take]));s=take[order]
            s=s[np.r_[True,meas[s][1:]!=meas[s][:-1]]];vals=val[s];n=len(s)
            row.update(n_times=n,last=float(vals[-1]),median=float(np.median(vals)),min=float(vals.min()),max=float(vals.max()))
            if n>=2:
                x=(meas[s]-meas[s[0]])/HOUR_NS
                row['std']=float(np.std(vals,ddof=0));row['delta']=float(vals[-1]-vals[0]);row['slope_per_hour']=float(np.polyfit(x,vals,1)[0]) if np.ptp(x)>0 else np.nan
            recent=vals[meas[s]>t-6*HOUR_NS];early=vals[(meas[s]>t-12*HOUR_NS)&(meas[s]<=t-6*HOUR_NS)]
            if len(recent) and len(early):row['late6_minus_early6']=float(recent.mean()-early.mean())
            order=np.lexsort((sid[take],-avail[take],priority[take],-meas[take]));s=take[order]
            ttl=cfg['vital_ttl_hours'] if feature in VITALS else cfg['lab_ttl_hours']
            ok=(meas[s][None,:]<=ends[:,None])&(avail[s][None,:]<=ends[:,None])&(meas[s][None,:]>=ends[:,None]-ttl*HOUR_NS)
            has=ok.any(axis=1);q=np.argmax(ok,axis=1)
            v[has,j]=val[s[q[has]]]
            fresh=ok&((avail[s][None,:]>left[:,None])|((np.arange(nbin)[:,None]==0)&(avail[s][None,:]==left[:,None])))
            m[:,j]=fresh.any(axis=1);age[has,j]=np.clip((ends[has]-meas[s[q[has]]])/HOUR_NS,0,hours)
        else:row['n_times']=0
        for k in cfg['summary_stats']:tab[feature+'__'+k]=row[k]
    return tab,v,m,age
